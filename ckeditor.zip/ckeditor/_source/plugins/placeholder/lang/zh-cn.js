﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'placeholder', 'zh-cn',
{
	placeholder :
	{
		title		: '占位符属性',
		toolbar		: '创建占位符',
		text		: '占位符文字',
		edit		: '编辑占位符',
		textMissing	: '占位符必需包含有文字'
	}
});
